export class User {
   id: number;
   name: String;
   email: String;
   password: String;
   api_token: String;
}