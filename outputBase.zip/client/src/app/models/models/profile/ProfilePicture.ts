export class ProfilePicture {
   id: number;
   file_type: String;
   file_name: String;
   file: String;
}