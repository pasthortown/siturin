export class SystemName {
   id: number;
   name: String;
}