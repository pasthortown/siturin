export class Ruc {
   id: number;
   number: String;
   baised_accounting: Boolean;
   contact_user_id: number;
   owner_name: String;
   tax_payer_type_id: number;
}