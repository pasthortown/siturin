export class Language {
   id: number;
   name: String;
}