export class EstablishmentCertificationType {
   id: number;
   name: String;
   code: String;
   father_code: String;
}