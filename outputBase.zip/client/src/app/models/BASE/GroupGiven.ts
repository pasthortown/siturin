export class GroupGiven {
   id: number;
   register_code: String;
   ruc_id: number;
   person_representative_id: number;
   group_type_id: number;
}