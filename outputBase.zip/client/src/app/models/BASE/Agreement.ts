export class Agreement {
   id: number;
   title: String;
   content: String;
}