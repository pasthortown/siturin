export class RucNameType {
   id: number;
   name: String;
   description: String;
}