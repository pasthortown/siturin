export class TaxPayerType {
   id: number;
   name: String;
   description: String;
}