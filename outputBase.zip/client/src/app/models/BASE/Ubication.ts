export class Ubication {
   id: number;
   name: String;
   code: String;
   father_code: String;
   gmap_reference_latitude: number;
   gmap_reference_longitude: number;
   acronym: String;
   constructor() {
      this.gmap_reference_latitude = 0;
      this.gmap_reference_longitude = 0;
   }
}