export class EstablishmentPropertyType {
   id: number;
   name: String;
}