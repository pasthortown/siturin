export class EstablishmentCertificationAttachment {
   id: number;
   establishment_certification_attachment_file_type: String;
   establishment_certification_attachment_file_name: String;
   establishment_certification_attachment_file: String;
}