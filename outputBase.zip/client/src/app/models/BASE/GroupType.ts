export class GroupType {
   id: number;
   name: String;
   description: String;
   representative_rol_name: String;
   representative_rol_description: String;
}