export class PreviewRegisterCode {
   id: number;
   code: String;
   system_name_id: number;
}