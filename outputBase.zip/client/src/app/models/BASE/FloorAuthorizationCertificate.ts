export class FloorAuthorizationCertificate {
   id: number;
   floor_authorization_certificate_file_type: String;
   floor_authorization_certificate_file_name: String;
   floor_authorization_certificate_file: String;
   register_id: number;
}