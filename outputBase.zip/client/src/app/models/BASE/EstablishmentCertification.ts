export class EstablishmentCertification {
   id: number;
   establishment_certification_type_id: number;
   establishment_certification_attachment_id: number;
}