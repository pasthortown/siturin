export class Worker {
   id: number;
   count: number;
   gender_id: number;
   worker_group_id: number;
}