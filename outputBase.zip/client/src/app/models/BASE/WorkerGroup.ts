export class WorkerGroup {
   id: number;
   name: String;
   description: String;
   is_max: Boolean;
}