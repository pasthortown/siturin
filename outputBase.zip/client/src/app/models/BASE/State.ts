export class State {
   id: number;
   name: String;
   description: String;
}