export class Gender {
   id: number;
   name: String;
}