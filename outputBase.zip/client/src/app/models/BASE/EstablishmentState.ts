export class EstablishmentState {
   id: number;
   justification: String;
   state_id: number;
   establishment_id: number;
}