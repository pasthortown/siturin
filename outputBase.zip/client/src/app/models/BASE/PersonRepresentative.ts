export class PersonRepresentative {
   id: number;
   identification: String;
}