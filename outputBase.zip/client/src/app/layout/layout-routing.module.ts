import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
   {
      path: '',
      component: LayoutComponent,
      children: [
         {
            path: '',
            redirectTo: 'main'
         },
         {
            path: 'main',
            loadChildren: './main/main.module#MainModule'
         },
         {
            path: 'profile',
            loadChildren: './profile/profile.module#ProfileModule'
         },

         //BASE

         {
            path: 'ruc',
            loadChildren: './CRUD/BASE/Ruc/ruc.module#RucModule'
         },
         {
            path: 'tax_payer_type',
            loadChildren: './CRUD/BASE/TaxPayerType/taxpayertype.module#TaxPayerTypeModule'
         },
         {
            path: 'establishment',
            loadChildren: './CRUD/BASE/Establishment/establishment.module#EstablishmentModule'
         },
         {
            path: 'person_representative',
            loadChildren: './CRUD/BASE/PersonRepresentative/personrepresentative.module#PersonRepresentativeModule'
         },
         {
            path: 'preview_register_code',
            loadChildren: './CRUD/BASE/PreviewRegisterCode/previewregistercode.module#PreviewRegisterCodeModule'
         },
         {
            path: 'system_name',
            loadChildren: './CRUD/BASE/SystemName/systemname.module#SystemNameModule'
         },
         {
            path: 'language',
            loadChildren: './CRUD/BASE/Language/language.module#LanguageModule'
         },
         {
            path: 'establishment_picture',
            loadChildren: './CRUD/BASE/EstablishmentPicture/establishmentpicture.module#EstablishmentPictureModule'
         },
         {
            path: 'ubication',
            loadChildren: './CRUD/BASE/Ubication/ubication.module#UbicationModule'
         },
         {
            path: 'worker',
            loadChildren: './CRUD/BASE/Worker/worker.module#WorkerModule'
         },
         {
            path: 'gender',
            loadChildren: './CRUD/BASE/Gender/gender.module#GenderModule'
         },
         {
            path: 'worker_group',
            loadChildren: './CRUD/BASE/WorkerGroup/workergroup.module#WorkerGroupModule'
         },
         {
            path: 'establishment_property_type',
            loadChildren: './CRUD/BASE/EstablishmentPropertyType/establishmentpropertytype.module#EstablishmentPropertyTypeModule'
         },
         {
            path: 'group_given',
            loadChildren: './CRUD/BASE/GroupGiven/groupgiven.module#GroupGivenModule'
         },
         {
            path: 'state',
            loadChildren: './CRUD/BASE/State/state.module#StateModule'
         },
         {
            path: 'establishment_state',
            loadChildren: './CRUD/BASE/EstablishmentState/establishmentstate.module#EstablishmentStateModule'
         },
         {
            path: 'establishment_certification',
            loadChildren: './CRUD/BASE/EstablishmentCertification/establishmentcertification.module#EstablishmentCertificationModule'
         },
         {
            path: 'establishment_certification_type',
            loadChildren: './CRUD/BASE/EstablishmentCertificationType/establishmentcertificationtype.module#EstablishmentCertificationTypeModule'
         },
         {
            path: 'establishment_certification_attachment',
            loadChildren: './CRUD/BASE/EstablishmentCertificationAttachment/establishmentcertificationattachment.module#EstablishmentCertificationAttachmentModule'
         },
         {
            path: 'group_type',
            loadChildren: './CRUD/BASE/GroupType/grouptype.module#GroupTypeModule'
         },
         {
            path: 'ruc_name_type',
            loadChildren: './CRUD/BASE/RucNameType/rucnametype.module#RucNameTypeModule'
         },
         {
            path: 'person_representative_attachment',
            loadChildren: './CRUD/BASE/PersonRepresentativeAttachment/personrepresentativeattachment.module#PersonRepresentativeAttachmentModule'
         },
         {
            path: 'agreement',
            loadChildren: './CRUD/BASE/Agreement/agreement.module#AgreementModule'
         },
         {
            path: 'floor_authorization_certificate',
            loadChildren: './CRUD/BASE/FloorAuthorizationCertificate/floorauthorizationcertificate.module#FloorAuthorizationCertificateModule'
         },
         {
            path: 'zone',
            loadChildren: './CRUD/BASE/Zone/zone.module#ZoneModule'
         },
         {
            path: 'blank',
            loadChildren: './blank-page/blank-page.module#BlankPageModule'
         },
         {
            path: 'not-found',
            loadChildren: './not-found/not-found.module#NotFoundModule'
         },
         {
            path: '**',
            redirectTo: 'not-found'
         }
      ]
   }
];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class LayoutRoutingModule {}