export const environment = {
  production: true,
  api: 'http://localhost:8000/',
  gmapapiKey: 'AIzaSyCZQgG8L6ntkJZarveWX9mvy9f9MMOoNDA',
};
